#include <iostream>
#include <cstdlib>
#include <yaml-cpp/yaml.h>
#include "invoice.h"

using namespace std;


void
usage(const char* name) {
  cerr << "Usage: " << name << " <yamlfile>.yaml" << endl;
  exit(0);
}

int
main(int argc, char *argv[]) {

  return 0;
}
